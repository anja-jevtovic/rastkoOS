#include "kernel/types.h"
#include "kernel/stat.h"
#include "user.h"

int
main(int argc, char *argv[])
{

    if(keyboard(1) < 0){
        fprintf(2, "fail: keyboard change unsuccessful\n");
    }

	exit();
}

